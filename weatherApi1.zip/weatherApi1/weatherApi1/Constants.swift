//
//  Constants.swift
//  weatherApi1
//
//  Created by yue xi on 12/13/23.
//

import Foundation
 

let baseURL = "https://us-central1-fir-api-s-8d31b.cloudfunctions.net/app"
let apiKey = ""
