//
//  weatherClass.swift
//  weatherApi1
//
//  Created by yue xi on 12/13/23.
//

import Foundation

class weatherClass {
    var cityCode: String = ""
    var city: String = ""
    var temperature: Int = 0
    var conditions: String = ""
}
