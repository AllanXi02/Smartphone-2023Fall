//
//  ViewController.swift
//  NameAndPhone
//
//  Created by yue xi on 12/9/23.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,SendDelegate {
        
    func sendNamePhoneNumber(name: String, phoneNumber: String) {
            names.append(name)
            phoneNumbers.append(phoneNumber)
            tblView.reloadData()
        }
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Name and Phone Segue" {
            let secondVC = segue.destination as! NameAndPhoneViewController
            secondVC.sendNamePhoneDelegate = self
        }
    }
    
    

    
    
    var names: [String] = [String]()
    var phoneNumbers: [String] = [String]()

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            let cell = tableView.dequeueReusableCell(withIdentifier: "tblCell", for: indexPath)
            cell.textLabel?.text = "Name: \(names[indexPath.row]) Phone: \(phoneNumbers[indexPath.row])"
            return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func AlertController(_ sender: Any) {
        performSegue(withIdentifier: "Name and Phone Segue", sender: self)
    }
    @IBOutlet weak var tblView: UITableView!
    
}

