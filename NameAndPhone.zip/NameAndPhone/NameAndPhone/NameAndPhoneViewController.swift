//
//  NameAndPhoneViewController.swift
//  NameAndPhone
//
//  Created by yue xi on 12/9/23.
//

import UIKit

class NameAndPhoneViewController: UIViewController {
    
    
    @IBOutlet weak var Phone: UITextField!
    
    @IBOutlet weak var Name: UITextField!
    
    var sendNamePhoneDelegate: SendDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func Save(_ sender: Any) {
        guard let name = Name.text else {return}
        guard let phoneNumber = Phone.text else {return}
        
        sendNamePhoneDelegate?.sendNamePhoneNumber(name: name, phoneNumber: phoneNumber)
        
        self.navigationController?.popViewController(animated: true)
        
        
        
    }
    
    
    
    
    
   
    
    
    
}
