//
//  SendDelegate.swift
//  NameAndPhone
//
//  Created by yue xi on 12/9/23.
//

import Foundation

protocol SendDelegate{
    func sendNamePhoneNumber(name: String, phoneNumber: String)
}
