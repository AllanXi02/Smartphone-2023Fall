//
//  ViewController.swift
//  WeatherAPI
//
//  Created by yue xi on 12/11/23.
//


import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
           tblView.dataSource = self
           tblView.delegate = self
    }

    var weatherValues : [weatherClass] = []
    var cityNames = ["SEA","SFO", "PDX", "NYC","MIA"]
    
    
    @IBOutlet weak var tblView: UITableView!
    
    
    @IBAction func getWeatherInfo(_ sender: Any) {
        var weathers = ""
        for weather in cityNames {
            weathers.append("\(weather),")
        }
        let weathersStr = weathers.dropLast()
        let url = "\(baseURL)"
//        这里api key 应该要删掉，
//        还有就是string 错误在哪
        print(url)
        SwiftSpinner.show("Getting City Weather Values")
        AF.request(url).responseJSON { response in
            SwiftSpinner.hide()
            if response.error != nil {
                print(response.error?.localizedDescription ?? "Error")
                return
            }
            guard let rawData = response.data else {return}
            guard let jsonArray = JSON(rawData).array else {return}
            
            self.weatherValues = [weatherClass]()
            for weatherJSON in jsonArray {
                print("weather : \(weatherJSON)")
                
                let cityCode = weatherJSON["cityCode"].stringValue
                let city = weatherJSON["city"].stringValue
                let conditions = weatherJSON["conditions"].stringValue
                let temperature = weatherJSON["temperature"].intValue
                
                let weatherClass = weatherClass()
                weatherClass.cityCode = cityCode
                weatherClass.city = city
                weatherClass.conditions = conditions
                weatherClass.temperature = temperature
                self.weatherValues.append(weatherClass)
            }
            self.tblView.reloadData()
//            print(self.weatherValues)

        }
    
    
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        weatherValues.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
//        cell.textLabel?.text = weatherValues[indexPath.row]
        let cityCode = weatherValues[indexPath.row].cityCode
        let city = weatherValues[indexPath.row].city
        let conditions = weatherValues[indexPath.row].conditions
        let temperature = weatherValues[indexPath.row].temperature
        cell.textLabel?.text = "cityCode: \(cityCode) "

        return cell
    }
    
    
    
    
    
}

