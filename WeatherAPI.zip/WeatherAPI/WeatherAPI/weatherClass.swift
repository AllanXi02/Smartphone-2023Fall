//
//  weatherClass.swift
//  WeatherAPI
//
//  Created by yue xi on 12/11/23.
//

import Foundation

class weatherClass {
    var cityCode: String = ""
    var city: String = ""
    var temperature: Int = 0
    var conditions: String = ""
}
